require 'rails_helper'

# Just test
RSpec.describe "test" do
  it "has a valid factory" do
    expect(true).to eq(true)
  end
end