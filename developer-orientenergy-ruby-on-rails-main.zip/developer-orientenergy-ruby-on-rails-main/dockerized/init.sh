#!/bin/bash

cd /usr/src/app

# bin/rails db:setup
# bin/rails db:migrate # RAILS_ENV=development
bin/rails db:prepare

rm -f tmp/pids/server.pid
bundle exec rdebug-ide --host 0.0.0.0 --port 1234 -- bin/rails s -b 0.0.0.0 &
bundle exec rdebug-ide --host 0.0.0.0 --port 1235 -- bin/bundle exec sidekiq -q callbacks -q default -q upload -q invoice_sync -q v2 -q stocklevels -c ${SIDEKIQ_FETCH_WORKER_CONCURRENCY:-10}