import React from 'react';
import { SafeAreaView, StyleSheet, ScrollView, View } from 'react-native';
import { Text, Chart, Header } from '@/components';
import DeviceCard from '@/components/home/DeviceCard';
import { Colors, sizeScale } from '@/commons';
import { sortByTime, getReadings, groupByDay } from '@/utils/reading';

const devices = [
	{
		label: 'Air conditioner',
		value: 0.3093,
	},
	{
		label: 'Wi-Fi router',
		value: 0.0033,
	},
	{
		label: 'Humidifer',
		value: 0.0518,
	},
	{
		label: 'Smart TV',
		value: 0.1276,
	},
	{
		label: 'Diffuser',
		value: 0.0078,
	},
	{
		label: 'Refrigerator',
		value: 0.0923,
	},
];

const Home = ({ navigation }) => {
	const readings = sortByTime(groupByDay(getReadings())).slice(-30);

	const renderDevices = () => {
		return (
			<View style={styles.deviceWrapper}>
				<View style={styles.deviceSection}>
					<Text color={Colors.main}>Your Devices:</Text>
				</View>
				{devices.map((device, idx) => (
					<DeviceCard key={idx} deviceInfo={device} />
				))}
			</View>
		);
	};

	return (
		<>
			<SafeAreaView backgroundColor={Colors.main} />
			<Header
				title='Energy Consumption'
				navigation={navigation}
				showBack
			/>
			<ScrollView style={styles.scrollView}>
				{renderDevices()}
				<Chart
					data={readings}
					title='Last 30 days wKh usage'
					height={150}
				/>
			</ScrollView>
		</>
	);
};

export default Home;
const styles = StyleSheet.create({
	scrollView: {
		backgroundColor: Colors.lighter,
	},
	deviceWrapper: {
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
		flexWrap: 'wrap',
		flexDirection: 'row',
		backgroundColor: Colors.white,
		marginHorizontal: sizeScale(8),
		paddingVertical: sizeScale(8),
		borderRadius: 6,
		marginTop: sizeScale(8),
	},
	deviceSection: {
		width: '100%',
		paddingLeft: sizeScale(8),
		marginBottom: sizeScale(8),
	}
});
