import React from 'react';
import { View, StyleSheet, SafeAreaView } from 'react-native';
import { Text, Header, Button } from '@/components';
import { Colors, sizeScale, Styles } from '@/commons';
import { ScrollView } from 'react-native-gesture-handler';

const Welcome = ({ navigation }) => {
	const start = () => navigation.navigate('Home');
	
	return (
		<View style={styles.container}>
			<SafeAreaView backgroundColor={Colors.main} />
			<Header title='Developer Orientenergy React Native' />

			<ScrollView contentContainerStyle={styles.scrollView}>
				<View style={styles.content}>
					<Text {...textWithMarginBottom} bold>
						Hello candidate,
					</Text>

					<Text {...textWithMarginBottom}>
						{
							'Welcome to join orient developer coding skills :)\nIn here you can show us of your coding knowledge and also demonstrate your experiences.\nFirstly, please see our requirement via our board.\nIf you aleardy have it, please ignore this message and continue to reading.'
						}
					</Text>

					<Text {...textWithMarginBottom}>
						{
							"Overall we'll check your result after receiving your submission."
						}
					</Text>

					<Text {...textProps}>
						{
							"Let's start coding, and we'll start from the FAP button to see you result. Thank you and all the best!"
						}
					</Text>
				</View>
				<View style={styles.buttonContainer}>
					<Button onPress={start} text="Let's start" />
				</View>
			</ScrollView>
		</View>
	);
};

export default Welcome;
const textProps = {
	size: 17,
	lineHeight: 27,
};
const textWithMarginBottom = {
	...textProps,
	marginBottom: 10,
};
const styles = StyleSheet.create({
	container: {
		...Styles.flex1,
		backgroundColor: Colors.white,
	},
	scrollView: {
		...Styles.flex1,
		padding: sizeScale(15),
	},
	content: {
		flex: 9,
	},
	buttonContainer: {
		flex: 1.5,
	},
});
