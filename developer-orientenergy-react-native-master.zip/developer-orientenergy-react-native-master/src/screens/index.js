import Home from './Home';
import Login from './Login';
import Welcome from './Welcome';

export {Login, Home, Welcome};
