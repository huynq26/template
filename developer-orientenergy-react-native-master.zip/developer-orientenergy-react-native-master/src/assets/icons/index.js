 
export const back = require('@/assets/icons/back.png'); 
export const company_logo = require('@/assets/icons/company_logo.jpg'); 
export const ic_empty = require('@/assets/icons/ic_empty.png'); 
