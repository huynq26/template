import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Home, Welcome} from '@/screens';

const Stack = createStackNavigator();

const AuthorizedStack = () => {
  return (
    <Stack.Navigator
      initialRouteName="Welcome"
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
			<Stack.Screen name='Welcome' component={Welcome} />
      <Stack.Screen name="Home" component={Home} />
    </Stack.Navigator>
  );
};

export default AuthorizedStack;
