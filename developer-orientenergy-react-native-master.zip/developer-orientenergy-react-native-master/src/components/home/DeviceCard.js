import React from 'react';
import { View, Dimensions, StyleSheet } from 'react-native';
import { colorOpacityMaker, Colors, sizeHeight, sizeScale } from '@/commons';
import { Text } from '@/components';
import { get } from 'lodash';

const DeviceCard = ({ deviceInfo = null }) => {
	return (
		<View style={styles.container}>
			<View style={styles.label}>
				<Text white>{get(deviceInfo, 'label', 'Unknown')}</Text>
			</View>

			<View style={styles.value}>
				<Text>{get(deviceInfo, 'value', 0)}kW</Text>
			</View>
		</View>
	);
};

export default DeviceCard;
const styles = StyleSheet.create({
	container: {
		width: Dimensions.get('window').width / 2 - sizeScale(25),
		backgroundColor: Colors.white,
		marginVertical: sizeScale(5),
		marginHorizontal: sizeScale(8),
		borderRadius: 6,
		height: sizeHeight(38),
	},
	label: {
		backgroundColor: colorOpacityMaker(Colors.main, 90),
		borderTopLeftRadius: 4,
		borderTopRightRadius: 4,
		padding: sizeScale(5),
		flex: 1,
		justifyContent: 'center',
	},
	value: {
		backgroundColor: colorOpacityMaker(Colors.main, 8),
		padding: sizeScale(5),
		flex: 1,
		justifyContent: 'center',
		borderBottomLeftRadius: 4,
		borderBottomRightRadius: 4,
	},
});
