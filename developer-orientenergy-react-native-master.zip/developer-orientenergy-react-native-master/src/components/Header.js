import React from 'react';
import { View, StyleSheet, Image, Platform } from 'react-native';
import { Text } from '@/components';
import { Colors, sizeScale } from '@/commons';
import { back } from '@/assets/icons';
import { TouchableOpacity } from 'react-native-gesture-handler';
const isAndroid = Platform.OS === 'android';

const Header = ({ title = '', showBack = false, navigation = null }) => {
	const onBack = () => {
		navigation && navigation.goBack();
	};

	return (
		<View style={styles.container}>
			{showBack && (
				<View style={styles.backButton}>
					<TouchableOpacity onPress={onBack}>
						<Image source={back} style={styles.backIcon} />
					</TouchableOpacity>
				</View>
			)}

			<Text size={18} white bold>
				{title}
			</Text>
		</View>
	);
};

export default Header;
const styles = StyleSheet.create({
	container: {
		height: sizeScale(isAndroid ? 50 : 40),
		backgroundColor: Colors.main,
		alignItems: 'center',
		paddingTop: isAndroid ? 0 : sizeScale(5),
		position: 'relative',
		justifyContent: isAndroid ? 'center' : 'flex-start'
	},
	backButton: {
		position: 'absolute',
		left: sizeScale(8),
		width: sizeScale(50),
		height: sizeScale(30),
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 99,
	},
	backIcon: {
		width: sizeScale(30),
		height: sizeScale(18),
		resizeMode: 'contain',
	},
});
