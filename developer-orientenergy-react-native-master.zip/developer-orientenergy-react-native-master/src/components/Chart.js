import React from 'react';
import { Dimensions, ScrollView, View, StyleSheet } from 'react-native';
import { BarChart } from 'react-native-chart-kit';
import { Text } from '@/components';
import { get } from 'lodash';
import { Colors } from '@/commons';
import { sizeHeight, sizeScale } from '@/commons/Responsive';

/**
 *
 * @param {*} data as array
 * [
 *  {
 *    time: timestamp
 *    value: 10
 *  }
 * ]
 * @returns
 */
const Chart = ({
	data = [],
	title = 'Last 30 days wKh usage',
	width = Dimensions.get('window').width * 4.5,
	height = 160
}) => {
	const labels = data.map((reading) => formatDateLabel(get(reading, 'time')));
	const values = data.map((reading) => get(reading, 'value', 0).toFixed(1));
	const chartData = {
		labels,
		datasets: [
			{
				data: values,
			},
		],
	};

	return (
		<View style={styles.container}>
			<Text marginTop={5} marginBottom={15} color={Colors.main}>
				{title}
			</Text>
			<ScrollView
				horizontal={true}
				showsHorizontalScrollIndicator={false} // to hide scroll bar
			>
				<BarChart
					data={chartData}
					style={styles.chartStyle}
					withHorizontalLabels={true}
					withInnerLines={false}
					width={width}
					height={sizeHeight(height)}
					chartConfig={chartConfig}
					fromZero
					showValuesOnTopOfBars
					showBarTops={false}
				/>
			</ScrollView>
		</View>
	);
};

const formatDateLabel = (timestamp) => {
	const date = new Date(timestamp);
	const month = date.getMonth();
	const day = date.getDate();

	const formatPart = (value) => {
		return value < 10 ? `0${value}` : `${value}`;
	};

	return `${formatPart(day)}/${formatPart(month + 1)}`;
};

const chartConfig = {
	backgroundGradientFrom: Colors.white,
	backgroundGradientTo: Colors.white,
	decimalPlaces: 0,
	color: () => Colors.main,
	labelColor: () => Colors.main,
	barPercentage: 1.3,
	fillShadowGradient: Colors.main,
	fillShadowGradientOpacity: 1,
	formatYLabel: (e) => {
		console.log(e);
		return e;
	},
};

export default Chart;
const styles = StyleSheet.create({
	container: {
		backgroundColor: Colors.white,
		padding: sizeScale(5),
		borderRadius: 6,
		margin: sizeScale(8),
		alignItems: 'center',
	},
	chartStyle: {
		paddingRight: 0,
	},
});
