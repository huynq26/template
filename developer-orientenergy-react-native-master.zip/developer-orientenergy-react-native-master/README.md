# Developer Orientenergy React Native 

## Install App Dependencies
****
1. Run `npm install`
****

## IOS Setup
****
1. Run `npm run ios:install`
****

## Run APP
****
1. Run `npm run ios` (ios)
2. Run `npm run android` (android)
****

## Troubleshooting
****
Android: if facing the error `spawn ./gradlew EACCES` -> run `chmod 755 android/gradlew`
****

## Project structure 
```
Project
│   README.md 
│   package.json
│   package-lock.json
|   index.js
|   icon-generate.js
│
└───ios
└───android
└───src
│   └───api-server
│       │   db.json
│       │   routes.json
│       │   package.json
│   └───assets
│        └───fonts
│        └───icons
│   └───commons
│        └───Api.js
│        └───Colors.js
│        └───Config.js
│        └───Constants.js
│        └───Responsive.js
│        └───Styles.js
│        └───index.js
│   └───components
│        └───Button.js
│        └───EmptyData.js
│        └───Text.js
│        └───index.js
│   └───routers
│        └───auth.router.js
│        └───authorized.router.js
│        └───root.router.js
│        └───index.js
│   └───screens
│        └───Home.js
│        └───Login.js
│        └───index.js
│   └───services
│        └───auth.service.js
│        └───user.service.js
│        └───index.js
│   └───store
│        └───actions
│        └───reducers
│        └───index.js
│   └───utils
│        └───alert.js
│        └───general.js
```
